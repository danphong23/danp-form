"""Blender lifecycle callbacks and runtime invalidation.

The callbacks are deliberately kept outside the package facade.  ``bind``
injects the small set of Source/controller adapters and shared runtime caches
after import, so registration and reload always point at one callback object.
"""

from __future__ import annotations

import bpy
from bpy.app.handlers import persistent
from mathutils import Vector

from .. import runtime
from ..constants import *
from . import transform_session as _transform_session
from .context import orphaned_owned_objects
from .workflows import update_revision

NATIVE_POLL_INTERVAL = 0.05
# Blender's native transform has no add-on confirm callback. In contexts that
# do not expose the active operator, wait for one second without mesh updates.
NATIVE_QUIET_POLLS = 20


def bind(api) -> None:
    for name in dir(api):
        if name.startswith("_"):
            globals()[name] = getattr(api, name)


@persistent
def _depsgraph_update_post(scene: bpy.types.Scene, depsgraph: bpy.types.Depsgraph) -> None:
    if runtime.SYNC_GUARD:
        return
    runtime.SYNC_GUARD = True
    try:
        _cleanup_orphaned_owned_objects()
        changed_geometry = {update.id.original.as_pointer() for update in depsgraph.updates if update.is_updated_geometry}
        for source, controller in _source_controller_pairs():
            source_changed = source.as_pointer() in changed_geometry or source.data.as_pointer() in changed_geometry
            controller_changed = controller.as_pointer() in changed_geometry or controller.data.as_pointer() in changed_geometry
            previous_proxy_snapshot = _PROXY_SNAPSHOTS.get(controller.as_pointer())
            modifier_key = source.as_pointer()
            previous_modifiers = runtime.MODIFIER_SIGNATURES.get(modifier_key)
            current_modifiers = _modifier_signature(source)
            modifier_changed = previous_modifiers != current_modifiers
            runtime.MODIFIER_SIGNATURES[modifier_key] = current_modifiers
            if not source_changed and not controller_changed and not modifier_changed:
                continue
            _OVERLAY_CACHE.clear()
            _PATCH_OVERLAY_CACHE.pop(source.as_pointer(), None)
            try:
                if source_changed:
                    _MAPPING_CACHE.pop(source.as_pointer(), None)
                    _FACE_CACHE.pop(source.as_pointer(), None)
                    _validate_source_topology(source)
                if modifier_changed:
                    _sync_controller_modifiers(source, controller)
                _guard_proxy_topology(source, controller)
                if (controller_changed and controller.mode == "EDIT"
                        and _controller_pose_changed(source, controller, previous_proxy_snapshot)):
                    # Blender restores the proxy to C0 on RMB/Esc. Detect it before calling
                    # update(); otherwise the timer can commit a cancelled
                    # preview or start the next mouse sample from a deformed
                    # Source pose (the cumulative-shrink bug).
                    session = runtime.NATIVE_TRANSFORM_SESSIONS.get(source.as_pointer())
                    if (session is not None
                            and session.get("had_delta")
                            and _transform_session._positions_close(
                                _transform_session.controller_positions(controller),
                                session.get("controller_rest", {}))):
                        _transform_session.cancel(source, controller, _workflow_dependencies())
                        bpy.context.scene.dan_form_status = "Native Controller transform cancelled"
                        continue
                    _observe_native_controller_transform(
                        source, controller, previous_proxy_snapshot
                    )
                # A native G/R/S session owns the live Controller Edit pose.
                # Pushing Source back into that proxy during the same
                # dependency-graph tick would visibly snap the transform and
                # lose numeric/axis-lock input.  The transform bridge performs
                # the final sync on commit or cancel.
                if source_changed and source.as_pointer() not in runtime.NATIVE_TRANSFORM_SESSIONS:
                    _sync_proxy(source, controller)
            except (KeyError, ValueError) as exc:
                if str(exc).startswith("TOPOLOGY_CHANGED"):
                    _set_topology_paused_status(source)
                elif str(exc).startswith("CONTROL_DATA_INVALID"):
                    bpy.context.scene.dan_form_status = f"Error: {exc}"
        active_source, _ = _context_source(bpy.context)
        _sync_ui_list(bpy.context.scene, active_source)
    except (AttributeError, RuntimeError, ValueError) as exc:
        if str(exc).startswith("TOPOLOGY_CHANGED"):
            active_source, _ = _context_source(bpy.context)
            if active_source is not None:
                _set_topology_paused_status(active_source)
        elif str(exc).startswith("CONTROL_DATA_INVALID") and bpy.context.scene is not None:
            bpy.context.scene.dan_form_status = f"Error: {exc}"
    finally:
        runtime.SYNC_GUARD = False


def _set_topology_paused_status(source) -> None:
    scene = getattr(bpy.context, "scene", None)
    if scene is not None:
        scene.dan_form_status = (
            f"DANP tạm dừng: topology của '{source.name}' đã thay đổi. "
            "Undo để khôi phục mapping hoặc Reset DANP để tạo control mới."
        )


def _cleanup_orphaned_owned_objects() -> int:
    removed = 0
    for obj in orphaned_owned_objects():
        mesh = getattr(obj, "data", None)
        try:
            bpy.data.objects.remove(obj, do_unlink=True)
            if mesh is not None and getattr(mesh, "users", 0) == 0 and bpy.data.meshes.get(mesh.name) is mesh:
                bpy.data.meshes.remove(mesh)
            removed += 1
        except (ReferenceError, RuntimeError):
            continue
    return removed


def _controller_pose_changed(source, controller, previous_snapshot) -> bool:
    """Distinguish coordinate transforms from selection-only Edit updates."""
    current_positions = _transform_session.controller_positions(controller)
    if previous_snapshot is None or len(previous_snapshot) < 4:
        try:
            return not _positions_close(current_positions, _source_positions(source))
        except (AttributeError, KeyError, RuntimeError, ValueError):
            return False
    previous_positions = {
        int(vertex_id): Vector(coordinates)
        for vertex_id, coordinates, _selected, _hidden in previous_snapshot[3][0]
    }
    return not _positions_close(current_positions, previous_positions)


def _controller_selection_changed(controller, transaction) -> bool:
    """Selection changes delimit transforms; proportional motion does not."""
    try:
        current = _controller_selected_source_ids(controller)
    except (AttributeError, KeyError, RuntimeError, ValueError):
        return False
    expected = transaction.get("selection", transaction.get("selected", ()))
    return set(current) != set(expected)


def _rest_from_proxy_snapshot(snapshot):
    if not snapshot or len(snapshot) < 4:
        return None
    try:
        return {int(vertex_id): Vector(coordinates)
                for vertex_id, coordinates, _selected, _hidden in snapshot[3][0]}
    except (IndexError, TypeError, ValueError):
        return None


def _observe_native_controller_transform(source, controller, previous_snapshot=None) -> None:
    """Bridge native Blender G/R/S edits without nesting a modal operator.

    Controller Edit remains entirely owned by Blender.  On the first native
    coordinate update we capture the DANP transaction rest, then update the
    Source from the live selected proxy coordinates.  A lightweight timer
    waits for Blender's transform operator to finish before committing the
    single transaction; canceling the native operation restores the proxy and
    therefore restores Source through the same path.
    """
    key = source.as_pointer()
    deps = _workflow_dependencies()
    session = runtime.NATIVE_TRANSFORM_SESSIONS.get(key)
    try:
        if session is None:
            session = _transform_session.begin(
                source, controller, deps, "NATIVE",
                controller_rest=_rest_from_proxy_snapshot(previous_snapshot),
            )
            session["idle_polls"] = 0
            session["timer_registered"] = False
        else:
            # A user can confirm a native transform and immediately select a
            # different vertex before the quiet timer closes the observer
            # session.  The transaction's selected ID set belongs to the
            # previous transform; feeding the new set into it produces
            # TARGET_INVALID and cancellation restores the old Source pose.
            # Commit the old preview from its immutable last targets first.
            transaction = session.get("transaction") or {}
            if _controller_selection_changed(controller, transaction):
                _transform_session.finalize_active(source, controller, deps)
                session = _transform_session.begin(
                    source, controller, deps, "NATIVE",
                    controller_rest=_rest_from_proxy_snapshot(previous_snapshot),
                )
                session["idle_polls"] = 0
                session["timer_registered"] = False
        scene = bpy.context.scene
        _transform_session.update(
            source,
            controller,
            deps,
            session,
            profile=getattr(scene, "dan_form_proportional_profile", "LINEAR"),
            radius=float(getattr(scene, "dan_form_proportional_radius", 0.0)),
        )
        # Every geometry sample means the modal transform is still alive.
        # Reset the quiet-poll counter here; otherwise a timer can commit a
        # transform while the mouse is still moving in contexts where
        # WindowManager.operators does not expose TRANSFORM_OT_*.
        session["idle_polls"] = 0
        if not session.get("timer_registered"):
            session["timer_registered"] = True
            bpy.app.timers.register(
                lambda source_ptr=key: _native_transform_timer(source_ptr),
                first_interval=NATIVE_POLL_INTERVAL,
            )
    except (ValueError, RuntimeError, KeyError):
        runtime.NATIVE_TRANSFORM_SESSIONS.pop(key, None)
        if key in deps.transactions:
            try:
                _transform_session.cancel(source, controller, deps)
            except (ValueError, RuntimeError):
                deps.transactions.pop(key, None)


def _native_transform_timer(source_ptr):
    session = runtime.NATIVE_TRANSFORM_SESSIONS.get(source_ptr)
    if session is None:
        return None
    source = next((obj for obj in bpy.data.objects if obj.as_pointer() == source_ptr), None)
    controller = next((obj for obj in bpy.data.objects if obj.as_pointer() == session["controller"]), None)
    if source is None or controller is None or controller.mode != "EDIT":
        if source is not None and controller is not None and source_ptr in _DANP_TRANSACTIONS:
            try:
                # Leaving Controller Edit Mode through "Back to Model" is a
                # normal completion path.  The old code treated every mode
                # change as cancellation and restored Source to p0, which
                # erased a valid edit immediately after the user left the
                # controller.  Preserve completed edits; only restore when
                # no transform delta was produced.
                if session.get("had_delta"):
                    _transform_session.commit(source, _workflow_dependencies())
                else:
                    _transform_session.cancel(source, controller, _workflow_dependencies())
            except (ValueError, RuntimeError):
                _DANP_TRANSACTIONS.pop(source_ptr, None)
        runtime.NATIVE_TRANSFORM_SESSIONS.pop(source_ptr, None)
        return None
    try:
        current = _transform_session.controller_positions(controller)
        # Selection can change without a geometry depsgraph update.  If it did
        # change before the timer's quiet window elapsed, close the previous
        # operation now; the next transform will create a fresh transaction.
        transaction = session.get("transaction") or {}
        if _controller_selection_changed(controller, transaction):
            _transform_session.finalize_active(source, controller, _workflow_dependencies())
            bpy.context.scene.dan_form_status = "Native Controller transform committed"
            return None
        # A cancelled modal transform restores the proxy to its immutable
        # rest pose.  Handle this before the native-operator probe so a
        # context with an empty WindowManager.operators list cannot turn the
        # restored pose into a committed zero/partial operation.
        if (session.get("had_delta")
                and _transform_session._positions_close(
                    current, session.get("controller_rest", {}))):
            _transform_session.cancel(source, controller, _workflow_dependencies())
            bpy.context.scene.dan_form_status = "Native Controller transform cancelled"
            return None
        if _transform_session.native_transform_active(bpy.context):
            session["idle_polls"] = 0
            return NATIVE_POLL_INTERVAL
        session["idle_polls"] = int(session.get("idle_polls", 0)) + 1
        # Some headless/MCP contexts do not expose the native operator in
        # WindowManager.Operators.  Require a few quiet polls so a single
        # dependency update cannot prematurely close a real transform.
        # Do not treat a short gap between mouse samples as confirmation.
        # In UI contexts where WindowManager.operators is empty, RMB/Esc can
        # need several timer ticks to restore the proxy to its rest pose.
        # A longer quiet window prevents committing an intermediate preview
        # that would later survive cancel and require Undo to remove.
        if session["idle_polls"] < NATIVE_QUIET_POLLS:
            return NATIVE_POLL_INTERVAL
        scene = bpy.context.scene
        _transform_session.update(
            source,
            controller,
            _workflow_dependencies(),
            session,
            profile=getattr(scene, "dan_form_proportional_profile", "LINEAR"),
            radius=float(getattr(scene, "dan_form_proportional_radius", 0.0)),
        )
        _transform_session.commit(source, _workflow_dependencies())
        bpy.context.scene.dan_form_status = "Native Controller transform committed"
    except (ValueError, RuntimeError, KeyError):
        try:
            _transform_session.cancel(source, controller, _workflow_dependencies())
        except (ValueError, RuntimeError):
            runtime.NATIVE_TRANSFORM_SESSIONS.pop(source_ptr, None)
    return None


@persistent
def _refresh_runtime(_unused=None, direction=None) -> None:
    runtime.PICK_SESSION += 1
    runtime.NATIVE_TRANSFORM_SESSIONS.clear()
    runtime.TOPOLOGY_STATES.clear()
    runtime.MODIFIER_SIGNATURES.clear()
    runtime.DANP_TRANSACTIONS.clear()
    # Undo/Redo may restore definitions, masks or coordinates.  Derived data
    # must be rebuilt from the restored Source rather than reused by identity.
    _MAPPING_CACHE.clear()
    _NETWORK_CACHE.clear()
    _PATCH_CACHE.clear()
    _PATCH_OVERLAY_CACHE.clear()
    _FACE_CACHE.clear()
    _OVERLAY_CACHE.clear()
    # Undo/redo handlers run inside Blender's undo stack.  Defer Source mesh
    # writeback until the handler has returned; writing BMesh data re-entrantly
    # from undo_post can deadlock or invalidate the active edit mesh.
    if direction in {"UNDO", "REDO"} and not runtime.NATIVE_UNDO_TIMER:
        runtime.NATIVE_UNDO_TIMER = True
        runtime.NATIVE_UNDO_DIRECTION = direction
        bpy.app.timers.register(
            lambda pending_direction=direction: _restore_native_undo_records(pending_direction),
            first_interval=0.05,
        )


@persistent
def _undo_post(_unused=None) -> None:
    _refresh_runtime(_unused, "UNDO")


@persistent
def _redo_post(_unused=None) -> None:
    _refresh_runtime(_unused, "REDO")


@persistent
def _load_post(_unused=None) -> None:
    runtime.NATIVE_UNDO_RECORDS.clear()
    _refresh_runtime(_unused)
    _PICK_PREVIEW.clear()
    _MAPPING_CACHE.clear()
    _UI_SIGNATURES.clear()
    _PROXY_SNAPSHOTS.clear()
    _NETWORK_CACHE.clear()
    _PATCH_CACHE.clear()
    _PATCH_OVERLAY_CACHE.clear()
    _FACE_CACHE.clear()
    _OVERLAY_CACHE.clear()
    _cleanup_orphaned_owned_objects()
    try:
        for source, controller in _source_controller_pairs():
            _migrate_control_schema(source)
            _sync_controller_modifiers(source, controller)
            _guard_proxy_topology(source, controller)
        _sync_context_ui_list(bpy.context)
    except (AttributeError, RuntimeError, ValueError) as exc:
        if str(exc).startswith("TOPOLOGY_CHANGED"):
            active_source, _ = _context_source(bpy.context)
            if active_source is not None:
                _set_topology_paused_status(active_source)
        elif str(exc).startswith("CONTROL_DATA_INVALID") and bpy.context.scene is not None:
            bpy.context.scene.dan_form_status = f"Error: {exc}"


def _update_revision(source: bpy.types.Object) -> None:
    update_revision(source)


def _positions_close(left, right, tolerance=1e-6) -> bool:
    if set(left) != set(right):
        return False
    return all((left[key] - right[key]).length <= tolerance for key in left)


def _restore_native_undo_records(direction: str):
    """Pair Blender's native proxy undo with the Source deformation state."""
    try:
        # Undo/Redo can restore a Source modifier stack without restoring the
        # Controller's derived stack. Reconcile that display/edit adapter first;
        # native transform history below remains independent of modifier state.
        for source, controller in _source_controller_pairs():
            try:
                _sync_controller_modifiers(source, controller)
            except (AttributeError, RuntimeError, TypeError, ValueError):
                continue
        for source_ptr, record in list(runtime.NATIVE_UNDO_RECORDS.items()):
            source = next((obj for obj in bpy.data.objects if obj.as_pointer() == source_ptr), None)
            if source is None and record.get("source_uuid"):
                matches = [obj for obj in bpy.data.objects
                           if obj.get(SOURCE_UUID_KEY) == record["source_uuid"]]
                source = matches[0] if len(matches) == 1 else None
            if source is None:
                runtime.NATIVE_UNDO_RECORDS.pop(source_ptr, None)
                continue
            if source.as_pointer() != source_ptr:
                runtime.NATIVE_UNDO_RECORDS[source.as_pointer()] = runtime.NATIVE_UNDO_RECORDS.pop(source_ptr)
            try:
                source_now = _source_positions(source)
                history = record.get("history", [])
                controllers = {obj.as_pointer(): obj for obj in bpy.data.objects}

                def controller_for(item):
                    controller = controllers.get(item.get("controller"))
                    if controller is not None:
                        return controller
                    matches = [obj for obj in bpy.data.objects
                               if obj.get(CONTROLLER_KEY) == source.get(SOURCE_UUID_KEY)]
                    return matches[0] if len(matches) == 1 else None

                def controller_pose_matches(item, expected_key):
                    controller = controller_for(item)
                    expected = item.get(expected_key, {})
                    if controller is None or not expected:
                        return False
                    try:
                        return _positions_close(
                            _transform_session.controller_positions(controller),
                            expected,
                        )
                    except (AttributeError, KeyError, RuntimeError, ValueError):
                        return False

                candidate = None
                if direction == "UNDO":
                    candidate = next(
                        (item for item in reversed(history)
                         if item.get("state") == "committed"
                         and (_positions_close(source_now, item.get("source_post", {}))
                              or _positions_close(source_now, item.get("source_pre", {})))
                         and controller_pose_matches(item, "controller_pre")),
                        None,
                    )
                elif direction == "REDO":
                    candidate = next(
                        (item for item in reversed(history)
                         if item.get("state") == "undone"
                         and (_positions_close(source_now, item.get("source_pre", {}))
                              or _positions_close(source_now, item.get("source_post", {})))
                         and controller_pose_matches(item, "controller_post")),
                        None,
                    )
                source_post = candidate.get("source_post", {}) if candidate else {}
                source_pre = candidate.get("source_pre", {}) if candidate else {}
                if direction == "UNDO" and candidate is not None and candidate.get("state") == "committed":
                    runtime.SYNC_GUARD = True
                    try:
                        if not _positions_close(source_now, source_pre):
                            _write_source_positions(source, source_pre)
                        controller = controller_for(candidate)
                        if controller is not None:
                            _sync_proxy(source, controller)
                    finally:
                        runtime.SYNC_GUARD = False
                    candidate["state"] = "undone"
                    record.update(candidate)
                elif direction == "REDO" and candidate is not None and candidate.get("state") == "undone":
                    runtime.SYNC_GUARD = True
                    try:
                        if not _positions_close(source_now, source_post):
                            _write_source_positions(source, source_post)
                        controller = controller_for(candidate)
                        if controller is not None:
                            _sync_proxy(source, controller)
                    finally:
                        runtime.SYNC_GUARD = False
                    candidate["state"] = "committed"
                    record.update(candidate)
            except (AttributeError, KeyError, RuntimeError, ValueError):
                continue
    finally:
        runtime.NATIVE_UNDO_TIMER = False
        runtime.NATIVE_UNDO_DIRECTION = None


__all__ = ["bind", "_depsgraph_update_post", "_refresh_runtime", "_undo_post", "_redo_post", "_load_post", "_update_revision", "_cleanup_orphaned_owned_objects"]
